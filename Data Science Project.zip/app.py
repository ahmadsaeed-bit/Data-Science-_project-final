import pickle
import pandas as pd
from flask import Flask, render_template, request
from sklearn.preprocessing import LabelEncoder

# Flask App
app = Flask(__name__)

# Load the pre-trained model
model_svr = pickle.load(open("model_svr.pkl", "rb"))

# Load the processed dataset to extract unique values for dropdowns
processed_data = pd.read_csv("processed_data.csv")

# Define the categorical and numeric columns
categorical_columns = ['Region', 'Season']
numeric_columns = ['CO2_ppm', 'Humidity_%', 'Pressure_hPa', 'WindSpeed_km_h','PollutionIndex', 'HeatIndex', 'Rainfall_mm']

# Load saved feature order and scaler to match training preprocessing
model_feature_order = pickle.load(open('model_columns.pkl', 'rb'))
scaler = pickle.load(open('scaler.pkl', 'rb'))

# Initialize label encoders for categorical columns
label_encoders = {'Region': LabelEncoder(), 'Season': LabelEncoder()}

# Fit label encoders on the categorical columns in the processed data
for col in categorical_columns:
    label_encoders[col].fit(processed_data[col])

# Mapping for readable names (encoded number -> display name)
region_mapping = {0: 'North', 1: 'South', 2: 'East', 3: 'West'}
season_mapping = {0: 'Winter', 1: 'Spring', 2: 'Summer', 3: 'Fall'}

# Reverse mapping for form submission (display name -> encoded number)
reverse_region_mapping = {v: k for k, v in region_mapping.items()}
reverse_season_mapping = {v: k for k, v in season_mapping.items()}

# Home Page Route
@app.route("/")
def index():
    # Fetch unique values for dropdowns with readable names
    region_values = sorted(processed_data['Region'].unique())
    season_values = sorted(processed_data['Season'].unique())
    
    sample_data = {
        'Region': [(code, region_mapping.get(code, f'Region {code}')) for code in region_values],
        'Season': [(code, season_mapping.get(code, f'Season {code}')) for code in season_values]
    }
    return render_template("index.html", sample_data=sample_data)

# Prediction Route
@app.route("/predict", methods=["POST"])
def predict():
    # Read numeric values
    input_data = {
        col: float(request.form.get(col)) for col in numeric_columns
    }

    # Read & convert categorical values from display names to encoded numbers
    region_name = request.form.get('Region')
    season_name = request.form.get('Season')
    
    # Convert display names back to encoded numbers
    region_code = reverse_region_mapping.get(region_name, 0)
    season_code = reverse_season_mapping.get(season_name, 0)
    
    input_data['Region'] = region_code
    input_data['Season'] = season_code

    # Convert to DataFrame and align with the model's training order
    input_df = pd.DataFrame([input_data])[model_feature_order]

    # Scale input features before prediction
    input_scaled = scaler.transform(input_df)

    # Make prediction
    predicted_temp = model_svr.predict(input_scaled)[0]

    # Fetch unique values for dropdowns with readable names
    region_values = sorted(processed_data['Region'].unique())
    season_values = sorted(processed_data['Season'].unique())
    
    sample_data = {
        'Region': [(code, region_mapping.get(code, f'Region {code}')) for code in region_values],
        'Season': [(code, season_mapping.get(code, f'Season {code}')) for code in season_values]
    }
    
    # Pass both sample_data and predicted_temp to the template
    return render_template("index.html", sample_data=sample_data, predicted_temp=round(predicted_temp, 2))


if __name__ == "__main__":
    app.run(debug=True)
